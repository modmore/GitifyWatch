<?php
$_lang['gitifywatch'] = 'Gitify Watch';

