<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2014 modmore | More for MODX

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.',
    'readme' => 'Gitify Watch
============

No, it\'s not a smart watch.. but it is a really cool plugin for MODX Revolution!

Gitify Watch is a MODX plugin to complement the Gitify command line tool. It hooks into various MODX events,
and will automatically extract and commit changes you make.

The primary purpose of Gitify Watch is to be sure changes made directly on production are immediately pushed to the git
remote, so it is easy to keep a development server up to date. With project-specific development, it could also be a
starting point for building a complete workflow away from the command line.

',
    'changelog' => 'Gitify Watch 2.0.0-rc1
----------------------
Released on 2022-09-23

- MODX 3 compatability
- Gitify 2 compatability

++ Gitify Watch 1.0.0-rc3
++ Released on 2015-10-07
+++++++++++++++++++++++++
- Fix undefined function error

++ Gitify Watch 1.0.0-rc2
++ Released on 2015-10-05
+++++++++++++++++++++++++
- Improved error handling related to fetching the environment information
- Make sure the push always targets the current branch

++ Gitify Watch 1.0.0-rc1
++ Released on 2015-09-30
+++++++++++++++++++++++++
- First testable release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '2593bf98bbdcd6e25d93236e29f04710',
      'native_key' => 'gitifywatch',
      'filename' => 'modNamespace/8ea7eba7411e21c5ddfa46a999805b96.vehicle',
      'namespace' => 'gitifywatch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bda93c75afb1a3bb1df1377b775b26f6',
      'native_key' => 'gitifywatch.repository_path',
      'filename' => 'modSystemSetting/fc8a520e7c718c9cdc5ff89ae089ad28.vehicle',
      'namespace' => 'gitifywatch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8826dd252ea7fce5ce020a0999a52e64',
      'native_key' => 'gitifywatch.gitify_path',
      'filename' => 'modSystemSetting/7ecc09a58b9c84a5b6e17a70539c5133.vehicle',
      'namespace' => 'gitifywatch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'c7ac7754c8576bad914a0cf10a560d80',
      'native_key' => NULL,
      'filename' => 'modCategory/ff3557af45e8862b0a55bc232a7202c1.vehicle',
      'namespace' => 'gitifywatch',
    ),
  ),
);