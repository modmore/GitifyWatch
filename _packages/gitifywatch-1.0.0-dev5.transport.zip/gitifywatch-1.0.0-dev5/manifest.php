<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2014 modmore | More for MODX

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.',
    'readme' => 'Gitify Watch
============

No, it\'s not a smart watch.. but it is a really cool plugin for MODX Revolution!

Gitify Watch is a MODX plugin to complement the Gitify command line tool. It hooks into various MODX events,
and will automatically extract and commit changes you make.

The primary purpose of Gitify Watch is to be sure changes made directly on production are immediately pushed to the git
remote, so it is easy to keep a development server up to date. With project-specific development, it could also be a
starting point for building a complete workflow away from the command line.

',
    'changelog' => '++ Gitify Watch 1.0.0-rc1
++ Released on 2015-04-15
+++++++++++++++++++++++++
- First public release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'e6485b3ddbf549537e340e58cedacff8',
      'native_key' => 'gitifywatch',
      'filename' => 'modNamespace/346906c58fbf3657803dc551c642939f.vehicle',
      'namespace' => 'gitifywatch',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a6a52a65fa4c7bfa9346248b7138474',
      'native_key' => 'gitifywatch.repository_path',
      'filename' => 'modSystemSetting/76f3f2e60bb3b35e08462aec91249a9a.vehicle',
      'namespace' => 'gitifywatch',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce0fd23c4bfb6462a1109312707a937a',
      'native_key' => 'gitifywatch.gitify_path',
      'filename' => 'modSystemSetting/fe6ecf0e50e30509dfed83bdcabf9093.vehicle',
      'namespace' => 'gitifywatch',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'cb54976aa1fe0a997ec710870d06866b',
      'native_key' => NULL,
      'filename' => 'modCategory/24a5315a1e17eb91cbc53e1629905928.vehicle',
      'namespace' => 'gitifywatch',
    ),
  ),
);